# dewew_downloader

GitHub fayllarini yuklab, istalgan loyihangizga joylashtiruvchi mini paket.
